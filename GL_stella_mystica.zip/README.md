# GL-StellaMystica

These fonts are free softwares.  
Unlimited permission is granted to use, copy, and distribute it, with or without modification, either commercially and noncommercially.  
THESE FONTS ARE PROVIDED "AS IS" WITHOUT WARRANTY.

これらのフォントはフリー（自由な）ソフトウエアです。  
あらゆる改変の有無に関わらず、また商業的な利用であっても、自由にご利用、複製、再配布することができますが、全て無保証とさせていただきます。

******

## GL-StellaMystica （オリジナル欧文フォント）

<img src="https://github.com/Gutenberg-Labo/GL-StellaMystica/blob/main/documents/GL-StellaMystica-Sample.svg" width="95%" alt="GL-StellaMystica - Open Source Font" />

Open source blackletter font with original design.  
Created with the design of the Arts and Crafts Movement of the late 19th century in mind.

オリジナルデザインのブラックレター系フォントです。  
19世紀末のアーツ・アンド・クラフツ運動のデザインを意識して作成しました。
